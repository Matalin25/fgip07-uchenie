const modules = [
  { id: 'u1', name: 'Первые шаги в Python', block: 'Основы', material: 'Напишите программу, которая спрашивает имя пользователя и печатает приветствие. Проверьте её на двух разных именах.' },
  { id: 'u2', name: 'Условия и ветвления', block: 'Основы', material: 'Напишите функцию, которая принимает целое число и возвращает «чётное» или «нечётное». Проверьте ноль и отрицательное число.' },
  { id: 'u3', name: 'Циклы и списки', block: 'Практика', material: 'Найдите сумму чётных элементов списка. Затем измените решение так, чтобы оно возвращало ноль для пустого списка.' },
  { id: 'u4', name: 'Функции и аргументы', block: 'Практика', material: 'Вынесите расчёт скидки в функцию. Добавьте значения по умолчанию и тест для неверного аргумента.' },
  { id: 'u5', name: 'Мини-проект', block: 'Итог', material: 'Соберите консольный список задач. Реализуйте добавление записи и отметку о выполнении. Опишите, как запустить программу.' }
];
const students = { daria: 'Дарья Волкова', ilya: 'Илья Орлов', sofia: 'София Ким' };
const statusMap = {
  start: ['К изучению','plain'], review: ['На проверке','ochre'],
  revise: ['Доработать','hot'], passed: ['Принято','good']
};
const model = storage('school', () => {
  const items = Object.fromEntries(Object.keys(students).map(id => [
    id, Object.fromEntries(modules.map(item => [item.id, { status: 'start', answer: '', feedback: '' }]))
  ]));
  Object.assign(items.daria.u1, { status: 'passed', answer: 'Сделала приветствие через input().', feedback: 'Задание принято, оба теста описаны.' });
  Object.assign(items.daria.u2, { status: 'passed', answer: 'Добавила проверку остатка от деления.', feedback: 'Граничные примеры учтены.' });
  Object.assign(items.daria.u3, { status: 'review', answer: 'Сумма через цикл и фильтр чётных чисел.' });
  Object.assign(items.ilya.u1, { status: 'review', answer: 'Отправляю решение, проверил на двух именах.' });
  Object.assign(items.sofia.u1, { status: 'passed', answer: 'Переменная name и вывод print().', feedback: 'Принято.' });
  return { items };
});
const items = model.state.items;
const navigation = [['course','▤','Учебный план'], ['queue','≡','На проверке']];
let role = 'student';
let student = 'daria';
let view = 'course';

function counts(id) {
  const results = Object.values(items[id]);
  const accepted = results.filter(result => result.status === 'passed').length;
  const waiting = results.filter(result => result.status === 'review').length;
  return { accepted, waiting, percentage: Math.round(accepted / modules.length * 100) };
}

function statusTag(status) {
  const [label, style] = statusMap[status];
  return `<span class="tag ${style}">${label}</span>`;
}

function queue() {
  return Object.keys(students).flatMap(id => modules.filter(module => items[id][module.id].status === 'review')
    .map(module => [id, module]));
}

function render() {
  nav(role === 'teacher' ? navigation : navigation.slice(0,1), view);
  putTop('Программа / <strong>Python с нуля</strong>', `
    <label class="role"><small>Демо-роль</small><select class="control" aria-label="Демо-роль" data-role>
      ${options([['student','Ученик'],['teacher','Куратор']], role)}</select></label>
    ${role === 'teacher' && view === 'course' ? `<select class="control" aria-label="Ученик" data-student>${options(Object.entries(students), student)}</select>` : ''}`);
  const summary = counts(student);
  const pending = queue();
  root.innerHTML = `
    <section class="hero"><div><h1>${role === 'teacher' ? 'Кабинет куратора' : 'Мой учебный план'}</h1>
    <p>${role === 'teacher' ? 'Проверка работ и прогресс учеников.' : 'Python с нуля · ' + students[student]}</p></div>
    <div class="hero-value"><b>${role === 'teacher' && view === 'queue' ? pending.length : summary.percentage + '%'}</b><span>${role === 'teacher' && view === 'queue' ? 'работ на проверке' : 'прогресс курса'}</span></div></section>
    ${metrics([['В программе', modules.length, 'Задания курса'], ['Принято', summary.accepted, students[student]], ['На проверке', role === 'teacher' ? pending.length : summary.waiting, role === 'teacher' ? 'У всей группы' : 'Ожидают куратора']])}
    ${view === 'queue' && role === 'teacher' ? renderQueue(pending) : renderPlan(summary)}`;
}

function renderPlan(summary) {
  const active = role === 'student' ? 'Открыть' : 'Подробнее';
  const rows = modules.map((module, index) => {
    const result = items[student][module.id];
    return `<li class="row"><div class="row-item"><span class="unit" aria-hidden="true">${index + 1}</span>
      <div><strong>${module.name}</strong><small>${module.block}${result.feedback ? ' · Есть комментарий' : ''}</small></div></div>
      <div class="row-end">${statusTag(result.status)}<button type="button" class="button" data-module="${module.id}" data-for="${student}" aria-label="${active}: ${module.name}">${active}</button></div></li>`;
  }).join('');
  return `<div class="section-head"><h2>Задания курса</h2></div><div class="split">
    <div class="panel"><h3 class="panel-title">Python с нуля</h3><ul class="rows">${rows}</ul></div>
    <aside class="panel pad"><h3>Прогресс ученика</h3>
    <strong data-progress>${summary.accepted} из ${modules.length}</strong><div class="progress" role="progressbar" aria-label="Завершение курса" aria-valuemin="0" aria-valuemax="100" aria-valuenow="${summary.percentage}"><span style="width:${summary.percentage}%"></span></div>
    <p>Прогресс учитывает работы, принятые куратором.</p>
    </aside></div>`;
}

function renderQueue(pending) {
  return `<div class="section-head"><h2>Очередь проверки</h2></div><div class="panel">
    <h3 class="panel-title">Сданные задания</h3><ul class="rows">${pending.map(([id,module]) => `<li class="row">
      <div class="row-item"><span class="unit" aria-hidden="true">${students[id].slice(0,1)}</span>
      <div><strong>${module.name}</strong><small>${students[id]}</small></div></div>
      <button type="button" class="button primary" data-module="${module.id}" data-for="${id}" aria-label="Проверить: ${module.name} — ${students[id]}">Проверить</button></li>`).join('') || '<li class="empty">Все работы проверены.</li>'}</ul></div>`;
}

function showModule(module, id) {
  if (!module || !items[id] || (role === 'student' && id !== student)) return;
  const result = items[id][module.id];
  const editable = role === 'student' && ['start','revise'].includes(result.status);
  const reviewing = role === 'teacher' && result.status === 'review';
  const action = editable ? '<button type="submit" class="button primary" value="send">Сдать задание</button>' :
    reviewing ? '<button type="submit" class="button" value="revise">На доработку</button><button type="submit" class="button primary" value="passed">Принять</button>' : '';
  openDialog(module.name, `
    <p class="muted">${escapeHtml(module.material)}</p>
    <p>${statusTag(result.status)}</p>
    ${editable ? `<label>Ответ<textarea name="answer" class="control" maxlength="700" required>${escapeHtml(result.answer)}</textarea></label>`
       : result.answer ? `<p><strong>Ответ ученика</strong></p><p class="muted" style="overflow-wrap:anywhere">${escapeHtml(result.answer)}</p>` : ''}
    ${reviewing ? `<label>Комментарий куратора (для возврата обязателен)<textarea name="feedback" class="control" maxlength="400">${escapeHtml(result.feedback)}</textarea></label>`
       : result.feedback ? `<p><strong>Комментарий куратора</strong></p><p class="muted" style="overflow-wrap:anywhere">${escapeHtml(result.feedback)}</p>` : ''}
    ${result.previousFeedback && !result.feedback ? `<p><strong>Предыдущий комментарий куратора</strong></p><p class="muted" style="overflow-wrap:anywhere">${escapeHtml(result.previousFeedback)}</p>` : ''}`,
    '<button class="button" type="button" data-close-form>Закрыть</button>' + action,
    (fields, outcome) => {
      if (outcome === 'send' && editable && role === 'student') {
        const answer = fields.get('answer').trim();
        if (!answer) return 'Введите ответ перед отправкой.';
        if (result.feedback) result.previousFeedback = result.feedback;
        Object.assign(result, { status: 'review', answer, feedback: '' });
      } else if (reviewing && role === 'teacher' && ['revise','passed'].includes(outcome)) {
        const feedback = fields.get('feedback').trim();
        if (outcome === 'revise' && !feedback) return 'Укажите, что нужно доработать.';
        Object.assign(result, { status: outcome, feedback });
      } else {
        return 'Это действие недоступно в текущей роли.';
      }
      model.save();
      dialog.close();
      render();
      notify(outcome === 'send' ? 'Работа отправлена куратору' : 'Решение сохранено');
    });
  dialog.querySelector('[data-close-form]').onclick = () => dialog.close();
}

document.addEventListener('click', event => {
  const button = event.target.closest('button');
  if (!button) return;
  if (button.dataset.view) {
    view = button.dataset.view;
    render();
    document.querySelector('[data-view="' + view + '"]').focus();
  }
  if (button.dataset.module) showModule(modules.find(module => module.id === button.dataset.module), button.dataset.for);
});
document.addEventListener('change', event => {
  const target = event.target;
  if (target.hasAttribute('data-role')) {
    role = target.value;
    if (role === 'student') student = 'daria';
    view = role === 'teacher' ? 'queue' : 'course';
    render();
    document.querySelector('[data-role]').focus();
  }
  if (target.hasAttribute('data-student') && role === 'teacher') {
    student = target.value;
    render();
    document.querySelector('[data-student]').focus();
  }
});
render();
