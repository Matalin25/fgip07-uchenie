# Дополнительная доработка в OpenCode

18 ноября 2026. OpenCode 1.19.6 и локальная модель Qwen3-1.7B.

Сохранить предыдущий комментарий после пересдачи. При новом возврате требовать новый комментарий.

## Запрос к модели

```text
Make one focused fix in app.js using the edit tool. When a student resubmits a revised answer, copy nonempty result.feedback to result.previousFeedback before resetting feedback to an empty string. When previousFeedback exists and feedback is empty, show the value as escaped text with the Russian label «Предыдущий комментарий куратора» after the current feedback UI in showModule(). This should be visible on a resubmitted work and after accepting it without a new comment. Keep the teacher input empty on resubmission so returning a project still requires a new comment. Old records may have no previousFeedback field. Edit app.js only and reply briefly.
```

## Применение

После проверки пробного результата подготовили точечный патч. OpenCode применил его с проверкой исходной и итоговой версий `app.js`.

```text
Use the bash tool now. Run this exact command once: node apply-checked.mjs . It applies the prepared edit to app.js. Call bash with command "node apply-checked.mjs" and description "Apply prepared app.js patch". Then reply with its result.
```

OpenCode вернул `Applied verified patch to app.js`. Запуск занял 10,3 с. Итоговый `app.js` имеет SHA-256 `353020740767acf61abd29dbc86321a23886caadc57b125083b554d65cb8c44b`.

## Повторная проверка

- Предыдущий комментарий виден ученику после повторной сдачи
- Поле новой заметки куратора пустое
- Новый возврат требует нового комментария
- Предыдущий комментарий остаётся после принятия и перезагрузки

[Скриншот](../../../evidence/uchenie-opencode.jpg).
